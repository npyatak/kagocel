function Cue( time ) {
	this.time = time;
	this.midiButton = 0;
	return this;
}